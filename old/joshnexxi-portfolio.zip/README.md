# joshnexxi.github.io

Personal portfolio site for Josh Nexxi.

## Publish with GitHub Pages

Create a public repository named exactly:

`joshnexxi.github.io`

Upload `index.html` to the root of the repository and commit it.

GitHub Pages should publish automatically for a repository using the `<username>.github.io` naming convention.
